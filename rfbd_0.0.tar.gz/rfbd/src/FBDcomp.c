/*
an object of class "phylo" with the following components:
edge a two-column matrix of mode numeric where each row represents an edge of the
tree; the nodes and the tips are symbolized with numbers; the tips are numbered
1, 2, . . . , and the nodes are numbered after the tips. For each row, the first
column gives the ancestor.
edge.length (optional) a numeric vector giving the lengths of the branches given by edge.
tip.label a vector of mode character giving the names of the tips; the order of the names
in this vector corresponds to the (positive) number in edge.
Nnode the number of (internal) nodes.
node.label (optional) a vector of mode character giving the names of the nodes.
https://informatique-mia.inra.fr/r4ciam/appelC.html
* http://adv-r.had.co.nz/C-interface.html#c-data-structures
* https://cran.r-project.org/doc/manuals/R-ints.html#The-_0027data_0027
*/

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <R.h>
#include <Rinternals.h>
#include <Rmath.h>
#include <math.h>
#include <time.h>
#include <pthread.h>
#include <signal.h>
#include "Utils.h"
#include "Tree.h"
#include "Fossil.h"
#include "FossilInt.h"
#include "Model.h"
#include "Uncertainty.h"
#include "MCMCImportanceSampling.h"
#include "Distribution.h"

#ifdef DO_PS
#endif

#define STRING_SIZE 300
#define INC_CUT 5
#define SEQ_SIZE 30
#define EXT_OUTPUT "_added.phy"
#define MAX_PRED 7.5E+07

#define SIZE_BUFFER_CHAR 300
#define INFTY 1E99
#define RINFTY 1E99
#define DEF 10
#define MIN_VAL 0.000001
#define DELTA 0.000001

#define MINVAL 0.01
#define TRIAL 10
#define FIX_VAL(x) (((x)<=0)?MINVAL:(x))

#define MAX_ITER 1000

#define M_MAX 6
#define M_MAX_F 4
#define MIN_TREE 20
#define PREFIX "table"
#define MAX_TRIALS 1000

#define HELPMESSAGE "--------------------------\n\nNAME\n	dist - Computation of the divergence time distibution associated to a given clade from a set of possible trees, the fossil ages, and the diversification rates\n	\nSYNOPSIS\n	dist [OPTIONS] <input Tree File> <input Fossil File> <input List Clade> [output File]\n\nDESCRIPTION\n	Compute the distribution of the divergence time associated to the clade corresponding to the list of tips given in <input List Clade> by sampling into the trees contianed in <input Tree File> (in Newick format) into the fossil ranges provided in <input Fossil File> (in csv format) and output the distribution as a .csv table <output File>.csv\n\n	Options are\n	-z <input Tree File>\n		output the tree in text debug format in the console and exit \n	-o <origin bound inf> [origin bound sup]\n		set the origin range; if origin bound sup is not given it is set to the most ancient fossil age\n	-e <end bound inf> <end bound sup>\n		set the end time range\n	-p <speciation rate> <extinction rate> <fossilization rate>\n		set the speciation, extinction and fossilization rates\n	-s <number>\n		set the number of samples\n	-d\n		return the distribution (otherwise the density is returned by default)\n	-u <value>\n		set the step discretizing the time distribution to <value>\n	-s <number>\n		set the number of thread running in parallell\n	-h\n		display help\n\n--------------------------\n\n"


static char **readList(FILE *f);


SEXP getListElement(SEXP list, const char *str) {
    SEXP elmt = R_NilValue, names = getAttrib(list, R_NamesSymbol);

    for (int i = 0; i < length(list); i++)
        if(strcmp(CHAR(STRING_ELT(names, i)), str) == 0) {
           elmt = VECTOR_ELT(list, i);
           break;
        }
    return elmt;
}


SEXP Tree2Newick(TypeTree *tree) {
	char *buf;
	buf = (char*) malloc(tree->size*200*sizeof(char));
	buf[0]= '\0';
	sprintTreeNewick(buf, tree);
	SEXP res = PROTECT(allocVector(STRSXP, 1));
	SET_STRING_ELT(res, 0, mkChar(buf));
	free((void*)buf);
	UNPROTECT(1);
	return res;
}

SEXP Tree2Phylo(TypeTree *tree) {
	SEXP phy;
	int n, i, j, ind = 0;
	double *bl;
	SEXP tipLabel, edge, nNode, edgeLength, list_names;
	SEXP dim;
	int nrow, ncol, *tab, *edgeP;
	double *edgeLengthP;
	char *namesList[4] = {"edge", "Nnode", "tip.label", "edge.length"};
	PROTECT(list_names = allocVector(STRSXP,4));
	for(i=0; i<4; i++)
		SET_STRING_ELT(list_names,i,mkChar(namesList[i]));
	edge = PROTECT(allocMatrix(INTSXP, tree->size-1, 2));
	edgeLength = PROTECT(allocVector(REALSXP, tree->size-1));
	tipLabel = PROTECT(allocVector(STRSXP, tree->root));
	edgeP = INTEGER(edge);
	edgeLengthP = REAL(edgeLength);
	for(n=0; n<tree->size; n++)
		if(n != tree->root) {
			edgeLengthP[ind] = tree->time[n];
			edgeP[ind] = tree->parent[n]+1;
			edgeP[ind+tree->size-1] = n+1;
			ind++;
		}
	for(i=0; i<tree->root; i++)
		SET_STRING_ELT(tipLabel,i,mkChar(tree->name[i]));
	nNode = PROTECT(allocVector(INTSXP, 1));
	INTEGER(nNode)[0] = tree->size-tree->root+1;
	PROTECT(phy = allocVector(VECSXP, 4));
	SET_VECTOR_ELT(phy, 0, edge);
	SET_VECTOR_ELT(phy, 1, nNode);
	SET_VECTOR_ELT(phy, 2, tipLabel);
	SET_VECTOR_ELT(phy, 3, edgeLength);
	SET_TYPEOF(phy, LANGSXP);
	return phy;
}	
	
TypeTree *Phylo2Tree(SEXP phy) {
	TypeTree *tree;
	int n, i, j;
	double *bl;
	SEXP namesTip, edge;
	SEXP dim;
	int nrow, ncol, *tab;

	n = INTEGER(getListElement(phy, "Nnode"))[0];
	bl = REAL(getListElement(phy, "edge.length"));
	edge = getListElement(phy, "edge");
	dim = getAttrib(edge, R_DimSymbol) ;
	nrow = INTEGER(dim)[0];
	ncol = INTEGER(dim)[1];
	tab = INTEGER(edge);
	tree = (TypeTree *) malloc(sizeof(TypeTree));
	tree->info = NULL;
	tree->comment = NULL;
	tree->parent = NULL;
	tree->size = 0;
	for(i=0; i<nrow*ncol; i++)
		if(tab[i]>tree->size)
			tree->size = tab[i];
	tree->sizeBuf = tree->size;
	tree->node = (TypeNode*) malloc(tree->sizeBuf*sizeof(TypeNode));
	tree->time = (double*) malloc(tree->sizeBuf*sizeof(double));
	tree->name = (char**) malloc(tree->sizeBuf*sizeof(char*));
	for(n=0; n<tree->size; n++) {
		tree->node[n].child = NOSUCH;
		tree->node[n].sibling = NOSUCH;
		tree->name[n] = NULL;
	}
	for(i=0; i<nrow; i++) {
		tree->node[tab[i+nrow]-1].sibling = tree->node[tab[i]-1].child;
		tree->node[tab[i]-1].child = tab[i+nrow]-1;
		tree->time[tab[i+nrow]-1] = bl[i];
	}
	namesTip = getListElement(phy, "tip.label");
	for(i=0; i<LENGTH(namesTip); i++) {
		tree->name[i] = strdpl((char*) CHAR(STRING_ELT(namesTip, i)));
	}
	tree->parent = getParent(tree);
	for(n=0; n<tree->size && tree->parent[n] != NOSUCH; n++)
		;
	tree->root = n;
	tree->time[tree->root] = NO_TIME;
	return tree;
}

SEXP getFBDProbabilityDistribution(SEXP cladeName, SEXP treeName, SEXP fossilName, SEXP outName, SEXP indName, SEXP minTimeIntInfR, SEXP minTimeIntSupR, SEXP maxTimeR, SEXP birthIR, SEXP deathIR, SEXP fossilIR, SEXP birthWSR, SEXP deathWSR, SEXP fossilWSR, SEXP propR, SEXP iterR, SEXP stepR, SEXP alR, SEXP burnR, SEXP gapR, SEXP probSpeR, SEXP probExtR, SEXP outDensR) {
	const char *inputFileNameTree, *inputFileNameList, *inputFileNameFossil, *outputFileNameOut, *outputFileNameInd;
	FILE *fi, *fl, *ff, *fout, *find;
	int iter, burn, gap, outDens;
	double minTimeIntInf = NO_TIME, minTimeIntSup = NO_TIME, maxTimeIntInf = 0., maxTime = 0., step, prop, al, probSpe, probExt;
	TypeModelParam windSize, init;
	
	inputFileNameTree = CHAR(asChar(treeName));
	inputFileNameList = CHAR(asChar(cladeName));
	inputFileNameFossil = CHAR(asChar(fossilName));
	outputFileNameOut = CHAR(asChar(outName));
	outputFileNameInd = CHAR(asChar(indName));
	iter = asInteger(iterR);
	burn = asInteger(burnR);
	gap = asInteger(gapR);
	al = asReal(alR);
	step = asReal(stepR);
	prop = asReal(propR);
	windSize.birth = asReal(birthWSR);
	windSize.death = asReal(deathWSR);
	windSize.fossil = asReal(fossilWSR);
	windSize.sampling = 0.;
	init.birth = asReal(birthIR);
	init.death = asReal(deathIR);
	init.fossil = asReal(fossilIR);
	init.sampling = 1.;
	minTimeIntInf = asReal(minTimeIntInfR);
	minTimeIntSup = asReal(minTimeIntSupR);
	maxTime = asReal(maxTimeR);
	probSpe = asReal(probSpeR);
	probExt = asReal(probExtR);
	outDens = asLogical(outDensR);


	if((fi = fopen(inputFileNameTree, "r")) && (fl = fopen(inputFileNameList, "r")) && (ff = fopen(inputFileNameFossil, "r"))) {
		TypeTree **tree;
		char **list;
		TypeFossilIntFeature **fos;
		TypeDistribution dist;
		int i, n, sizeTree, s, *node, nT, cont;

		list = readList(fl);
		fclose(fl);
        tree = readTrees(fi);
        fclose(fi);
        if(tree[0] == NULL) {
			error("Error: no tree\n");
			return R_NilValue;
		}
		sizeTree = 0;
		for(sizeTree=0; tree[sizeTree]!=NULL; sizeTree++)
			;
		fos = (TypeFossilIntFeature**) malloc(sizeTree*sizeof(TypeFossilIntFeature*));
		node = (int*) malloc(sizeTree*sizeof(int));
		for(i=0; i<sizeTree; i++) {
			int n;
			toBinary(tree[i]);
			if(tree[i]->name!=NULL)
				for(n=0; n<tree[i]->size; n++)
					if(tree[i]->name[n]!=NULL)
						fixSpace(tree[i]->name[n]);
			n = getClade(list, tree[i]);
			if(n != NOSUCH) {
				node[i] = n;
				tree[i] = tree[i];
				rewind(ff);
				fos[i] = getFossilIntFeature(ff, tree[i]->name, tree[i]->size);
				if(getMaxFossilIntTime(fos[i]) > 0.)
					negateFossilInt(fos[i]);
				fixStatus(tree[i], fos[i]);
			} else
				error("clade not found\n");
		}
        fclose(ff);
		for(i=0; list[i]!=NULL; i++)
			free((void*)list[i]);
		free((void*)list);
		double minFossilTime = getMinFossilIntTime(fos[0]);
		if(isnan(minTimeIntInf) || minTimeIntInf > minFossilTime) {
			if(minFossilTime<0)
				minTimeIntInf = 1.2*minFossilTime;
			else
				minTimeIntInf = 0.8*minFossilTime;
		}
		for(i=0; i<sizeTree; i++) {
			tree[i]->minTime = minTimeIntInf;
			tree[i]->minTimeInt.inf = minTimeIntInf;
			tree[i]->minTimeInt.sup = (isnan(minTimeIntSup))?NO_TIME:minTimeIntSup;
			tree[i]->maxTime = maxTimeIntInf;
		}

		if((fout = fopen(outputFileNameOut, "w")) && (find = fopen(outputFileNameInd, "w"))) {
			dist = MCMCSamplingDist(fout, find, tree, sizeTree, node, fos, al, burn, gap, iter, prop, &windSize, &init, step, probSpe, probExt);
			fclose(fout);
			fclose(find);
			for(i=0; i<sizeTree; i++) {
				freeTree(tree[i]);
				freeFossilIntFeature(fos[i]);
			}
			free((void*)tree);
			free((void*)fos);
			free((void*)node);
			if(outDens)
				deriveDistribution(&dist);
//FILE * fo;
//if(fo = fopen("distribution.csv", "w")) {
	//fprintDistribution(fo, dist);
	//fclose(fo);
//}
//fprintf(stderr, "Distribution\n\n");
			SEXP ans = PROTECT(allocMatrix(REALSXP, dist.size, 2));
			double *rans = REAL(ans);
			for(i=0; i < dist.size; i++) {
				rans[i] = dist.item[i].val;
				rans[i+dist.size] = dist.item[i].dens;
			}
			//SEXP dimnames = PROTECT(allocVector(VECSXP, 2));
			//SET_VECTOR_ELT(dimnames, 0, "X");
			//SET_VECTOR_ELT(dimnames, 1, "Y");
			//setAttrib(ans, R_DimNamesSymbol, dimnames);
			if(dist.item != NULL)
				free((void*)dist.item);
			UNPROTECT(1);
			return ans;
		} else {
			error("Cannot open output files %s or %s\n", outputFileNameOut, outputFileNameInd);
			return R_NilValue;
		}
	} else {
		error("Cannot read %s or %s or %s\n", inputFileNameTree, inputFileNameList, inputFileNameFossil);
		return R_NilValue;
	}
	return R_NilValue;
}

SEXP getFBDProbabilityDiagnostic(SEXP treeName, SEXP fossilName, SEXP outName, SEXP indName, SEXP minTimeIntInfR, SEXP minTimeIntSupR, SEXP maxTimeR, SEXP birthIR, SEXP deathIR, SEXP fossilIR, SEXP birthWSR, SEXP deathWSR, SEXP fossilWSR, SEXP propR, SEXP iterR, SEXP alR, SEXP burnR, SEXP gapR, SEXP probSpeR, SEXP probExtR) {
	const char *inputFileNameTree, *inputFileNameFossil, *outputFileNameOut, *outputFileNameInd;
	FILE *fi, *fl, *ff, *fout, *find;
	int iter, burn, gap;
	double minTimeIntInf = NO_TIME, minTimeIntSup = NO_TIME, maxTimeIntInf = 0., maxTime = 0., prop, al, probSpe, probExt;
	TypeModelParam windSize, init;

	inputFileNameTree = CHAR(asChar(treeName));
	inputFileNameFossil = CHAR(asChar(fossilName));
	outputFileNameOut = CHAR(asChar(outName));
	outputFileNameInd = CHAR(asChar(indName));
	iter = asInteger(iterR);
	burn = asInteger(burnR);
	gap = asInteger(gapR);
	al = asReal(alR);
	prop = asReal(propR);
	windSize.birth = asReal(birthWSR);
	windSize.death = asReal(deathWSR);
	windSize.fossil = asReal(fossilWSR);
	windSize.sampling = 0.;
	init.birth = asReal(birthIR);
	init.death = asReal(deathIR);
	init.fossil = asReal(fossilIR);
	init.sampling = 1.;
	minTimeIntInf = asReal(minTimeIntInfR);
	minTimeIntSup = asReal(minTimeIntSupR);
	maxTime = asReal(maxTimeR);
	probSpe = asReal(probSpeR);
	probExt = asReal(probExtR);
	if((fi = fopen(inputFileNameTree, "r")) && (ff = fopen(inputFileNameFossil, "r"))) {
		TypeTree **tree;
		TypeFossilIntFeature **fos;
		TypeDistribution dist;
		int i, n, sizeTree, s, nT, cont;

        tree = readTrees(fi);
        fclose(fi);
        if(tree[0] == NULL) {
			error("Error: no tree\n");
			return R_NilValue;
		}
		sizeTree = 0;
		for(sizeTree=0; tree[sizeTree]!=NULL; sizeTree++)
			;
		fos = (TypeFossilIntFeature**) malloc(sizeTree*sizeof(TypeFossilIntFeature*));
		for(i=0; i<sizeTree; i++) {
			int n;
			toBinary(tree[i]);
			if(tree[i]->name!=NULL)
				for(n=0; n<tree[i]->size; n++)
					if(tree[i]->name[n]!=NULL)
						fixSpace(tree[i]->name[n]);
			tree[i] = tree[i];
			rewind(ff);
			fos[i] = getFossilIntFeature(ff, tree[i]->name, tree[i]->size);
			if(getMaxFossilIntTime(fos[i]) > 0.)
				negateFossilInt(fos[i]);
			fixStatus(tree[i], fos[i]);
		}
        fclose(ff);
		double minFossilTime = getMinFossilIntTime(fos[0]);
		if(isnan(minTimeIntInf) || minTimeIntInf > minFossilTime) {
			if(minFossilTime<0)
				minTimeIntInf = 1.2*minFossilTime;
			else
				minTimeIntInf = 0.8*minFossilTime;
		}
		for(i=0; i<sizeTree; i++) {
			tree[i]->minTime = minTimeIntInf;
			tree[i]->minTimeInt.inf = minTimeIntInf;
			tree[i]->minTimeInt.sup = (isnan(minTimeIntSup))?NO_TIME:minTimeIntSup;
			tree[i]->maxTime = maxTimeIntInf;
		}
		if((fout = fopen(outputFileNameOut, "w")) && (find = fopen(outputFileNameInd, "w"))) {
			MCMCSamplingDiag(fout, find, tree, sizeTree, fos, al, burn, gap, iter, prop, &windSize, &init, probSpe, probExt);
			fclose(fout);
			fclose(find);
			for(i=0; i<sizeTree; i++) {
				freeTree(tree[i]);
				freeFossilIntFeature(fos[i]);
			}
			free((void*)tree);
			free((void*)fos);
			return R_NilValue;
		} else {
			error("Cannot open output files %s or %s\n", outputFileNameOut, outputFileNameInd);
			return R_NilValue;
		}
	} else {
if(!(fi = fopen(inputFileNameTree, "r")))
			error("Cannot open %s\n", inputFileNameTree);
if(!(ff = fopen(inputFileNameFossil, "r")))
			error("Cannot open %s\n", inputFileNameFossil);
//		error("Cannot open input files %s or %s\n", inputFileNameTree, inputFileNameFossil);
		return R_NilValue;
	}
	return R_NilValue;
}

#define MAX_SIZE_TMP 50
#define INC_BUFFER 50
#define IS_SEP(c) (c == ' ' || c == '\t' || c == '\r' || c == '\n' || c == ';')

char **readList(FILE *f) {
	char c, tmp[MAX_SIZE_TMP+1], **list;
	int size, sizeBuffer;

	sizeBuffer = INC_BUFFER;
	list= (char**) malloc(sizeBuffer*sizeof(char*));
	size = 0;
	do {
		c = getc(f);
	} while(c!=EOF && IS_SEP(c)); 
	while(c != EOF) {
		int i;
		i = 0;
		while(i<MAX_SIZE_TMP && c !=EOF && !IS_SEP(c)) {
			tmp[i] = c;
			c = getc(f);
			i++;
		}
		tmp[i++] = '\0';
		if(i == MAX_SIZE_TMP) {
			error("Ident too long (%s) ...", tmp);
		}
		if(i>1) {
			if(size >= sizeBuffer) {
				sizeBuffer += INC_BUFFER;
				list = (char**) realloc((void *) list, sizeBuffer*sizeof(char*));
			}
			list[size] = (char*) malloc((strlen(tmp)+1)*sizeof(char));
			strcpy(list[size], tmp);
			size++;
		}
		while(c!=EOF && IS_SEP(c))
			c=getc(f);
	}
	if(size >= sizeBuffer) {
		sizeBuffer += INC_BUFFER;
		list = (char**) realloc((void *) list, sizeBuffer*sizeof(char*));
	}
	list[size++] = NULL;
	return list;
}
