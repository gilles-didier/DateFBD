

#library(ade4)
#library(ape)
#dyn.load("treeR.so")

#testTree <- function(tree, part) {
#phy <- read.tree(tree)
#.Call("drawPhylo", phy, "bof.tex")
#list <- scan(part, what = " ")
#new <- .Call("prunePhylo", phy, list)
#phy2 <- read.tree(text = new)
#}

FBDdistribution <- function(treeName, cladeName, fossilName, outName = "coda_output.out", indName = "coda_output.ind", inf_origin=NaN, sup_origin=NaN, end_time=0., spec_wind_size=1., exti_wind_size=0.5, foss_wind_size=0.5, spec_init=1., exti_init=0.5, foss_init=0.5, iter=2000, prop = 0.5, step=0.1, al = 0.75, burn = 10000, thin = 300, prop_spe = 0.33, prop_ext = 0.33, outDens = TRUE) {
	res <-.Call("getFBDProbabilityDistribution", treeName, cladeName, fossilName, outName, indName, inf_origin, sup_origin, end_time, spec_init, exti_init, foss_init, spec_wind_size, exti_wind_size, foss_wind_size, prop, iter, step, al,  burn, thin, prop_spe, prop_ext, outDens)
	res
}

FBDdiagnostic <- function(treeName, cladeName, fossilName, outName = "coda_output.out", indName = "coda_output.ind", inf_origin=NaN, sup_origin=NaN, end_time=0., spec_wind_size=1., exti_wind_size=0.5, foss_wind_size=0.5, spec_init=1., exti_init=0.5, foss_init=0.5, iter=2000, prop = 0.5, step=0.1, al = 0.75, burn = 10000, thin = 300, prop_spe = 0.33, prop_ext = 0.33) {
	res <-.Call("getFBDProbabilityDiagnostic", treeName, cladeName, fossilName, outName, indName, inf_origin, sup_origin, end_time, spec_init, exti_init, foss_init, spec_wind_size, exti_wind_size, foss_wind_size, prop, iter, step, al,  burn, thin, prop_spe, prop_ext)
	res
}
