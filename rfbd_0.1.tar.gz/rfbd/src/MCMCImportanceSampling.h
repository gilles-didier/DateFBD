#ifndef MCMCImportanceSamplingF
#define MCMCImportanceSamplingF

#include <stdlib.h>
#include <stdio.h>

#include "Tree.h"
#include "Fossil.h"
#include "FossilInt.h"
#include "Model.h"




#ifdef __cplusplus
extern "C" {
#endif

TypeDistribution MCMCSamplingSpeciationDist(FILE *fout, FILE *find, int *node, TypeTree **tree, TypeFossilIntFeature *fi, double step, double al, int burn, int gap, int iter, double prop, TypeModelParam *windSize, TypeModelParam *init, double probSpe, double probExt);
void MCMCSamplingDiag(FILE *fout, FILE *find, TypeTree **tree, TypeFossilIntFeature *fi, double al, int burn, int gap, int iter, double prop, TypeModelParam *windSize, TypeModelParam *init, double probSpe, double probExt);
TypeDistribution *MCMCSamplingExtinctionDist(FILE *fout, FILE *find, int **taxa, TypeTree **tree, TypeFossilIntFeature *fi, double maxDisplayTime, double step, double al, int burn, int gap, int iter, double prop, TypeModelParam *windSize, TypeModelParam *init, double probSpe, double probExt);
double *MCMCSamplingExtinctionDistQuantMean(FILE *fout, FILE *find, double order, int **clade, TypeTree **tree, TypeFossilIntFeature *fi, double al, int burn, int gap, int iter, double prop, TypeModelParam *windSize, TypeModelParam *init, double probSpe, double probExt);
double MCMCSamplingExtinctionComp(FILE *fout, FILE *find, int *cladeA, int *cladeB, TypeTree **tree, TypeFossilIntFeature *fi, double al, int burn, int gap, int iter, double prop, TypeModelParam *windSize, TypeModelParam *init, double probSpe, double probExt);
#ifdef __cplusplus
}
#endif



#endif
