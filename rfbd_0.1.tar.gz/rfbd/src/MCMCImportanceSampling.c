#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>

#include "Utils.h"
#include "Uncertainty.h"
#include "MCMCImportanceSampling.h"


static void fillFolNode(TypeFossilFeature *f, int size, int *fol);
static void fillBranchNode(TypeFossilFeature *f, int size, int *branch);
static void  getProposalFossil(TypeFossilFeature *fp, TypeFossilIntFeature *fi, int *fol, double al, int *move, double *newTime);
static void changeFossil(TypeTree **tree, int nTree, TypeFossilFeature *fp, int *fol, int *branch, int move, double newTime);
static double update(TypeTree **tree, int nTree, TypeFossilFeature *fp, TypeFossilIntFeature *fi, int *fol, int *branch, double prob, double al, double propParam, TypeModelParam *param, TypeModelParam *windSize, double probSpe, double probExt);
static TypeFossilFeature *sampleFossil(TypeFossilIntFeature* feat, int size);
static int compareLocal(const void* a, const void* b);
static double getLogDensitySum(TypeTree **tree, int nTree, TypeFossilFeature *fp, TypeModelParam *param);
static double getLogProbExtinctCondCladeSum(double val, int *clade, double maxTime, TypeExtendedModelParam *param, double **time, int size);
static double getQuantileCladeSum(int *clade, double q, double tol, double maxTime, TypeExtendedModelParam *param, double **time, int size);
static double getLogProbComp(int *cladeA, int *cladeB, double maxTime, TypeExtendedModelParam *param, double *time);

static TypeFossilList *fossilList;

/*return log(a+b) in an accurate way*/
double logSum(double a,double b) {
	double max, min;
	if(a>b) {
		max = a;
		min = b;
	} else {
		min = a;
		max = b;
	}
	return log(max) + log1p(min/max);
}

/*return log(exp(a)+exp(b)) in an accurate way*/
double logSumLog(double a, double b) {
	double max, min;
	if(a == NEG_INFTY)
		return b;
	if(b == NEG_INFTY)
		return a;
	if(a>b) {
		max = a;
		min = b;
	} else {
		min = a;
		max = b;
	}
	return max + log1p(exp(min-max));
}


int compareLocal(const void* a, const void* b) {
    if(fossilList[*((int*)a)].time>fossilList[*((int*)b)].time)
        return 1;
    if(fossilList[*((int*)a)].time<fossilList[*((int*)b)].time)
        return -1;
    return 0;
}

TypeFossilFeature *sampleFossil(TypeFossilIntFeature* feat, int size) {
    TypeFossilFeature *sample;
    int i, n, f, *tmp;

    if(feat == NULL)
        return NULL;
    sample = (TypeFossilFeature*) malloc(sizeof(TypeFossilFeature));
    sample->size = feat->sizeFossil;
    sample->sizeBuf = feat->sizeFossil;
    sample->fossilList = (TypeFossilList*) malloc(sample->size*sizeof(TypeFossilList));
    sample->fossil = (int*) malloc(size*sizeof(int));
    sample->status = (TypeNodeStatus*) malloc(size*sizeof(int));
    for(i=0; i<size; i++)
        sample->fossil[i] = feat->fossilInt[i];
    for(i=0; i<sample->size; i++) {
        sample->fossilList[i].prec = feat->fossilIntList[i].prec;
        sample->fossilList[i].time = feat->fossilIntList[i].fossilInt.inf+UNIF_RAND*(feat->fossilIntList[i].fossilInt.sup-feat->fossilIntList[i].fossilInt.inf);
    }
    fossilList = sample->fossilList;
    tmp = (int*) malloc((sample->size+1)*sizeof(int));
    for(n=0; n<size; n++) {
        int ind = 0;
        for(f=sample->fossil[n]; f!=NOSUCH; f=sample->fossilList[f].prec)
            tmp[ind++] = f;
        if(ind>0) {
            qsort(tmp, ind, sizeof(int), compareLocal);
            sample->fossilList[tmp[0]].prec = NOSUCH;
            for(f=1; f<ind; f++)
                sample->fossilList[tmp[f]].prec = tmp[f-1];
            sample->fossil[n] = tmp[ind-1];
        }
    }
    free((void*) tmp);
    return sample;
}


void fillFolNode(TypeFossilFeature *f, int size, int *fol) {
	int n;
	for(n=0; n<size; n++) {
		int k, tmp;
		tmp = NOSUCH;
		for(k=f->fossil[n]; k!=NOSUCH; k=f->fossilList[k].prec) {
			fol[k] = tmp;
			tmp = k;
		}
	}
}

void fillBranchNode(TypeFossilFeature *f, int size, int *branch) {
	int n;
	for(n=0; n<size; n++) {
		int k;
		for(k=f->fossil[n]; k!=NOSUCH; k=f->fossilList[k].prec)
			branch[k] = n;
	}
}

TypeModelParam getProposalParam(TypeModelParam *param, TypeModelParam *windSize, double probSpe, double probExt) {
	TypeModelParam res;
	double p = UNIF_RAND;
	res = *param;
	if(p<probSpe) {
		res.birth = UNIF_RAND*windSize->birth+param->birth-0.5*windSize->birth;
			if(res.birth < 0.)
				res.birth = -res.birth;
	} else {
		if(p<probSpe+probExt) {
			res.death = UNIF_RAND*windSize->death+param->death-0.5*windSize->death;
			if(res.death < 0.)
				res.death = -res.death;
		} else {
			res.fossil = UNIF_RAND*windSize->fossil+param->fossil-0.5*windSize->fossil;
			if(res.fossil < 0.)
				res.fossil = -res.fossil;
		}
	}
	return res;
}

void getProposalFossil(TypeFossilFeature *fp, TypeFossilIntFeature *fi, int *fol, double al, int *move, double *newTime) {
	double length;
    *move = RANGE_RAND(fp->size);
    length = (fi->fossilIntList[*move].fossilInt.sup-fi->fossilIntList[*move].fossilInt.inf)*al/2.;
    *newTime = UNIF_RAND*(2.*length)+fp->fossilList[*move].time-length;
    if(*newTime<fi->fossilIntList[*move].fossilInt.inf)
		*newTime = 2.*fi->fossilIntList[*move].fossilInt.inf - *newTime;
    if(*newTime>fi->fossilIntList[*move].fossilInt.sup)
		*newTime = 2.*fi->fossilIntList[*move].fossilInt.sup - *newTime;
}

void changeFossil(TypeTree **tree, int nTree, TypeFossilFeature *fp, int *fol, int *branch, int move, double newTime) {
	int xA, xB, change, i;
	change = (tree[0]->time[branch[move]] == fp->fossilList[fp->fossil[branch[move]]].time);
	fp->fossilList[move].time = newTime;
	xA = NOSUCH;
	for(xB=fol[move]; xB!=NOSUCH && fp->fossilList[move].time>fp->fossilList[xB].time; xB=fol[xB])
		xA = xB;
	if(xB != fol[move]) {;
		if(fol[move] != NOSUCH)
			fp->fossilList[fol[move]].prec = fp->fossilList[move].prec;
		else
			fp->fossil[branch[move]] = fp->fossilList[move].prec;
		if(fp->fossilList[move].prec != NOSUCH)
			fol[fp->fossilList[move].prec] = fol[move];
		if(xB != NOSUCH)
			fp->fossilList[xB].prec = move;
		else
			fp->fossil[branch[move]] = move;
		if(xA != NOSUCH)
			fol[xA] = move;
		fol[move] = xB;
		fp->fossilList[move].prec = xA;
	}
	xA = NOSUCH;
	for(xB=fp->fossilList[move].prec; xB!=NOSUCH && fp->fossilList[move].time<fp->fossilList[xB].time; xB=fp->fossilList[xB].prec)
		xA = xB;
	if(xB != fp->fossilList[move].prec) {
		if(fol[move] != NOSUCH)
			fp->fossilList[fol[move]].prec = fp->fossilList[move].prec;
		else
			fp->fossil[branch[move]] = fp->fossilList[move].prec;
		if(fp->fossilList[move].prec != NOSUCH)
			fol[fp->fossilList[move].prec] = fol[move];
		if(xB != NOSUCH)
			fol[xB] = move;
		if(xA != NOSUCH)
			fp->fossilList[xA].prec = move;
		fol[move] = xA;
		fp->fossilList[move].prec = xB;
	}
	double min = getMinFossilTime(fp);
	if(tree[0]->minTimeInt.sup > min)
		for(i=0; i<nTree; i++)
			tree[i]->minTimeInt.sup = min;
	if(change)
		for(i=0; i<nTree; i++)
			tree[i]->time[branch[move]] = fp->fossilList[fp->fossil[branch[move]]].time;
}

double update(TypeTree **tree, int nTree, TypeFossilFeature *fp, TypeFossilIntFeature *fi, int *fol, int *branch, double prob, double al, double propParam, TypeModelParam *param, TypeModelParam *windSize, double probSpe, double probExt) {
	int move;
	double newTime, oldTime, newProb;
	if(UNIF_RAND < propParam) {
		TypeModelParam newParam = getProposalParam(param, windSize, probSpe, probExt);
		newProb = getLogDensitySum(tree, nTree, fp, &newParam);
		if(isnan(newProb))
			error("Param %.2le %.2le %.2le\n", newParam.birth, newParam.death, newParam.fossil);
		if(UNIF_RAND < exp(newProb-prob)) {
			*param = newParam;
			return newProb;
		} else {
			return prob;
		}
	} else { 	
		getProposalFossil(fp, fi, fol, al, &move, &newTime);
		oldTime = fp->fossilList[move].time;
		changeFossil(tree, nTree, fp, fol, branch, move, newTime);
		newProb = getLogDensitySum(tree, nTree, fp, param);
		if(isnan(newProb))
			error("fossil %d %.5lf -> %.5lf (%d %s) time %.5lf\n", move, oldTime, newTime, branch[move], tree[0]->name[branch[move]], tree[0]->time[branch[move]]);
		if(UNIF_RAND < exp(newProb-prob)) {
			return newProb;
		} else {
			changeFossil(tree, nTree, fp, fol, branch, move, oldTime);
			return prob;
		}
	}
	return prob;
}

double getLogDensitySum(TypeTree **tree, int nTree, TypeFossilFeature *fp, TypeModelParam *param) {
	double sum;
	int i;
	sum = NEG_INFTY;
	for(i=0; i<nTree; i++)
		sum = logSumLog(sum, getLogLikelihoodTreeFossil(tree[i], fp, param));
	return sum;
}

TypeDistribution MCMCSamplingSpeciationDist(FILE *fout, FILE *find, int *node, TypeTree **tree, TypeFossilIntFeature *fi, double step, double al, int burn, int gap, int iter, double prop, TypeModelParam *windSize, TypeModelParam *init, double probSpe, double probExt) {
	int *fol, *branch, i, j, s, n, nTree;
	double prob, min, max, *logCond, logSumCond;
	TypeFossilFeature *fp;
	TypeDistribution *logDTmp, logSTmp, dist;
	TypeModelParam param, *saveParam;
	param.birth = UNIF_RAND*init->birth;
	param.death = UNIF_RAND*init->death;
	param.fossil = UNIF_RAND*init->fossil;
	param.sampling = 1.;

Rprintf("step %lf al %lf burn %d gap %d iter %d prop %lf probSpe %lf probExt %lf ws.birth %lf ws.death %lf ws.fossil %lf ws.sampl %lf in.birth %lf in.death %lf in.fossil %lf in.sampl %lf\n", step, al, burn, gap, iter, prop, probSpe, probExt, windSize->birth, windSize->death, windSize->fossil, windSize->sampling, init->birth, init->death, init->fossil, init->sampling);
	fp = sampleFossil(fi, tree[0]->size);
	for(nTree=0; tree[nTree] != NULL; nTree++) {
		for(n=0; n<tree[nTree]->size; n++) {
			if(tree[nTree]->node[n].child == NOSUCH) {
				switch(fi->status[n]) {
					case contempNodeStatus:
						tree[nTree]->time[n] = tree[nTree]->maxTime;
					break;
					case unknownNodeStatus:

					break;
					case extinctNodeStatus:
						tree[nTree]->time[n] = fp->fossilList[fp->fossil[n]].time;
					break;
					default:
						;
				}
			} else
				tree[nTree]->time[n] = NO_TIME;
		}
	}
	fol = (int*) malloc(fp->size*sizeof(int));
	fillFolNode(fp, tree[0]->size, fol);
	branch = (int*) malloc(fp->size*sizeof(int));
	fillBranchNode(fp, tree[0]->size, branch);
	min = getMaxFossilIntTimeToNode(node[0], tree[0], fi);
	max = getMinFossilIntTimeFromNode(node[0], tree[0], fi);
	min = floor(min/step)*step;
	max = (ceil(max/step))*step;
	double **save;
	int f;
	saveParam = (TypeModelParam*) malloc(iter*sizeof(TypeModelParam));
	save = (double**) malloc(fp->size*sizeof(double*));
	for(f=0; f<fp->size; f++)
		save[f] = (double*) malloc(iter*sizeof(double));
	prob = getLogDensitySum(tree, nTree, fp, &param);

	for(i=0; i<burn; i++) {
		prob = update(tree, nTree, fp, fi, fol, branch, prob, al, prop, &param, windSize, probSpe, probExt);
	}
	logSumCond = NEG_INFTY;
	logCond = (double*) malloc(nTree*sizeof(double));
	logSTmp.size = (int) ceil((max-min)/step)+1;
	logSTmp.item = (TypeDistributionItem*) malloc(logSTmp.size*sizeof(TypeDistributionItem));
	logDTmp = (TypeDistribution*) malloc(nTree*sizeof(TypeDistribution));
	for(i=0; i<nTree; i++) {
		logDTmp[i].size = logSTmp.size;
		logDTmp[i].item = (TypeDistributionItem*) malloc(logSTmp.size*sizeof(TypeDistributionItem));
	}
	dist.size = logSTmp.size;
	dist.item = (TypeDistributionItem*) malloc(dist.size*sizeof(TypeDistributionItem));
	for(j=0; j<logSTmp.size; j++) {
		for(i=0; i<nTree; i++)
			logDTmp[i].item[j].val = min + ((double)j)*step;
		logSTmp.item[j].val = min + ((double)j)*step;
		dist.item[j].val = min + ((double)j)*step;
		dist.item[j].dens = NEG_INFTY;
	}
	for(s=0; s<iter; s++) {
		int j;
		logSumCond = NEG_INFTY;
		for(j=0; j<logSTmp.size; j++)
			logSTmp.item[j].dens = NEG_INFTY;
		for(i=0; i<nTree; i++) {
			fillLogDistribution(&(logDTmp[i]), &(logCond[i]), node[i], tree[i], fp, &param);
			logSumCond = logSumLog(logSumCond, logCond[i]);
			for(j=0; j<dist.size; j++)
				logSTmp.item[j].dens = logSumLog(logSTmp.item[j].dens, logDTmp[i].item[j].dens);
		}
		for(j=0; j<dist.size; j++)
			dist.item[j].dens = logSumLog(dist.item[j].dens, logSTmp.item[j].dens-logSumCond);
		saveParam[s] = param;
		for(f=0; f<fp->size; f++)
			save[f][s] = fp->fossilList[f].time;
		for(j=0; j<gap; j++) {
			prob = update(tree, nTree, fp, fi, fol, branch, prob, al, prop, &param, windSize, probSpe, probExt);
		}
	}
	for(j=0; j<dist.size; j++)
		dist.item[j].dens = exp(dist.item[j].dens-log((double)iter));
	for(s=0; s<iter; s++)
		fprintf(fout, "%d\t%lf\n",  s+burn+1, saveParam[s].birth);
	for(s=0; s<iter; s++)
		fprintf(fout, "%d\t%lf\n",  s+burn+1, saveParam[s].death);
	for(s=0; s<iter; s++)
		fprintf(fout, "%d\t%lf\n",  s+burn+1, saveParam[s].fossil);
	free((void*)saveParam);
	for(f=0; f<fp->size; f++)
		for(s=0; s<iter; s++)
			fprintf(fout, "%d\t%lf\n",  s+burn+1, save[f][s]);
	for(f=0; f<fp->size; f++)
		free((void*)save[f]);
	free((void*)save);
	int off = 0;
	fprintf(find, "birth\t%d\t%d\n", off*iter+1, (off+1)*iter); off++;
	fprintf(find, "death\t%d\t%d\n", off*iter+1, (off+1)*iter); off++;
	fprintf(find, "fossil\t%d\t%d\n", off*iter+1, (off+1)*iter); off++;
	for(f=0; f<fp->size; f++) {
		fprintf(find, "%d", f+1);
		if(branch[f] != NOSUCH && tree[0]->name[branch[f]] != NULL)
			fprintf(find, "_%s_%d_%d", tree[0]->name[branch[f]], (int) round(fi->fossilIntList[f].fossilInt.inf), (int) round(fi->fossilIntList[f].fossilInt.sup));
		fprintf(find, "\t%d\t%d\n", off*iter+1, (off+1)*iter); off++;
	}
	freeFossilFeature(fp);
	free((void*)branch);
	free((void*)fol);
	free((void*)logSTmp.item);
	for(i=0; i<nTree; i++)
		free((void*)logDTmp[i].item);
	free((void*)logDTmp);
	free((void*)logCond);
	return dist;
}

void MCMCSamplingDiag(FILE *fout, FILE *find, TypeTree **tree, TypeFossilIntFeature *fi, double al, int burn, int gap, int iter, double prop, TypeModelParam *windSize, TypeModelParam *init, double probSpe, double probExt) {
	int *fol, *branch, f, i , s, n, *todo, nTodo = 0, nTree;
	double prob, **save, **saveTodo;
	TypeFossilFeature *fp;
	TypeModelParam param, *saveParam;
	
	param.birth = UNIF_RAND*init->birth;
	param.death = UNIF_RAND*init->death;
	param.fossil = UNIF_RAND*init->fossil;
	param.sampling = 1.;
	
	todo = (int*) malloc(sizeof(int)*(tree[0]->size/2+2));
	for(n=0; n<tree[0]->size; n++)
		if(tree[0]->node[n].child == NOSUCH && fi->status[n] == extinctNodeStatus)
			todo[nTodo++] = n;
	fp = sampleFossil(fi, tree[0]->size);
	for(nTree=0; tree[nTree] != NULL; nTree++) {
		for(n=0; n<tree[nTree]->size; n++) {
			if(tree[nTree]->node[n].child == NOSUCH) {
				switch(fi->status[n]) {
					case contempNodeStatus:
						tree[nTree]->time[n] = tree[nTree]->maxTime;
					break;
					case unknownNodeStatus:

					break;
					case extinctNodeStatus:
						tree[nTree]->time[n] = fp->fossilList[fp->fossil[n]].time;
					break;
					default:
	//						error("Node %d has no status\n", n);
	;
				}
			} else
				tree[nTree]->time[n] = NO_TIME;
		}
	}
	fol = (int*) malloc(fp->size*sizeof(int));
	fillFolNode(fp, tree[0]->size, fol);
	branch = (int*) malloc(fp->size*sizeof(int));
	fillBranchNode(fp, tree[0]->size, branch);
	saveParam = (TypeModelParam*) malloc(iter*sizeof(TypeModelParam));
	save = (double**) malloc(fp->size*sizeof(double*));
	for(f=0; f<fp->size; f++)
		save[f] = (double*) malloc(iter*sizeof(double));
	saveTodo = (double**) malloc(nTodo*sizeof(double*));
	for(n=0; n<nTodo; n++)
		saveTodo[n] = (double*) malloc(iter*sizeof(double));
	prob = getLogDensitySum(tree, nTree, fp, &param);
	for(i=0; i<burn; i++) {
		prob = update(tree, nTree, fp, fi, fol, branch, prob, al, prop, &param, windSize, probSpe, probExt);
	}
	for(s=0; s<iter; s++) {
		int j, f;
		saveParam[s] = param;
		for(f=0; f<fp->size; f++)
			save[f][s] = fp->fossilList[f].time;
		for(n=0; n<nTodo; n++)
			saveTodo[n][s] = tree[0]->time[todo[n]];
		for(j=0; j<gap; j++) {
			prob = update(tree, nTree, fp, fi, fol, branch, prob, al, prop, &param, windSize, probSpe, probExt);
		}
	}
	for(s=0; s<iter; s++)
		fprintf(fout, "%d\t%lf\n",  s+burn+1, saveParam[s].birth);
	for(s=0; s<iter; s++)
		fprintf(fout, "%d\t%lf\n",  s+burn+1, saveParam[s].death);
	for(s=0; s<iter; s++)
		fprintf(fout, "%d\t%lf\n",  s+burn+1, saveParam[s].fossil);
	free((void*)saveParam);
	for(f=0; f<fp->size; f++)
		for(s=0; s<iter; s++)
			fprintf(fout, "%d\t%lf\n",  s+burn+1, save[f][s]);
	for(f=0; f<fp->size; f++)
		free((void*)save[f]);
	free((void*)save);
	for(n=0; n<nTodo; n++)
		for(s=0; s<iter; s++)
			fprintf(fout, "%d\t%lf\n",  s+burn+1, saveTodo[n][s]);
	for(n=0; n<nTodo; n++)
		free((void*)saveTodo[n]);
	free((void*)saveTodo);
	int off = 0;
	fprintf(find, "birth\t%d\t%d\n", off*iter+1, (off+1)*iter); off++;
	fprintf(find, "death\t%d\t%d\n", off*iter+1, (off+1)*iter); off++;
	fprintf(find, "fossil\t%d\t%d\n", off*iter+1, (off+1)*iter); off++;
	for(f=0; f<fp->size; f++) {
		fprintf(find, "%d", f+1);
		if(branch[f] != NOSUCH && tree[0]->name[branch[f]] != NULL)
			fprintf(find, "_%s_%d_%d", tree[0]->name[branch[f]], (int) round(fi->fossilIntList[f].fossilInt.inf), (int) round(fi->fossilIntList[f].fossilInt.sup));
		fprintf(find, "\t%d\t%d\n", off*iter+1, (off+1)*iter); off++;
	}
	for(n=0; n<nTodo; n++) {
		if(tree[0]->name[todo[n]] != NULL)
			fprintf(find, "%s", tree[0]->name[todo[n]]);
		else
			fprintf(find, "node_%d", todo[n]);
		fprintf(find, "\t%d\t%d\n", off*iter+1, (off+1)*iter); off++;
	}
	free((void*)todo);
	free((void*)branch);
	free((void*)fol);
}

TypeDistribution *MCMCSamplingExtinctionDist(FILE *fout, FILE *find, int **clade, TypeTree **tree, TypeFossilIntFeature *fi, double maxDisplayTime, double step, double al, int burn, int gap, int iter, double prop, TypeModelParam *windSize, TypeModelParam *init, double probSpe, double probExt) {
	int *fol, *branch, i, j, f, s, n, nTree = 0, nClade = 0, nExt = 0, *ext;
	double prob, **save, **saveExt, min;
	TypeFossilFeature *fp;
	TypeDistribution *d, *logSTmp;
	TypeModelParam param, *saveParam;
	TypeExtendedModelParam pext;
	
	param.birth = UNIF_RAND*init->birth;
	param.death = UNIF_RAND*init->death;
	param.fossil = UNIF_RAND*init->fossil;
	param.sampling = 1.;
	fp = sampleFossil(fi, tree[0]->size);
	for(nTree=0; tree[nTree] != NULL; nTree++) {
		for(n=0; n<tree[nTree]->size; n++) {
			if(tree[nTree]->node[n].child == NOSUCH) {
				switch(fi->status[n]) {
					case contempNodeStatus:
						tree[nTree]->time[n] = tree[nTree]->maxTime;
					break;
					case unknownNodeStatus:

					break;
					case extinctNodeStatus:
						tree[nTree]->time[n] = fp->fossilList[fp->fossil[n]].time;
					break;
					default:
	//						error("Node %d has no status\n", n);
	;
				}
			} else
				tree[nTree]->time[n] = NO_TIME;
		}
	}
	ext = (int*) malloc(tree[0]->size*sizeof(int));
	for(n=0; n<tree[0]->size; n++)
		if(tree[0]->node[n].child == NOSUCH && fi->status[n] == extinctNodeStatus)
			ext[nExt++] = n;
	fol = (int*) malloc(fp->size*sizeof(int));
	fillFolNode(fp, tree[0]->size, fol);
	branch = (int*) malloc(fp->size*sizeof(int));
	fillBranchNode(fp, tree[0]->size, branch);
	saveParam = (TypeModelParam*) malloc(iter*sizeof(TypeModelParam));
	save = (double**) malloc(fp->size*sizeof(double*));
	for(f=0; f<fp->size; f++)
		save[f] = (double*) malloc(iter*sizeof(double));
	saveExt = (double**) malloc(nExt*sizeof(double*));
	for(n=0; n<nExt; n++)
		saveExt[n] = (double*) malloc(iter*sizeof(double));
	prob = getLogDensitySum(tree, nTree, fp, &param);
	for(i=0; i<burn; i++) {
		prob = update(tree, nTree, fp, fi, fol, branch, prob, al, prop, &param, windSize, probSpe, probExt);
	}
	for(nClade=0; clade[nClade]!=NULL; nClade++)
		;
	min = getMaxFossilIntTimeToNode(ext[0], tree[0], fi);
	for(n=1; n<nExt; n++) {
		if(getMaxFossilIntTimeToNode(ext[n], tree[0], fi)<min)
			min = getMaxFossilIntTimeToNode(ext[n], tree[0], fi);
	}
	min = floor(min/step)*step;
	logSTmp = (TypeDistribution*) malloc(nClade*sizeof(TypeDistribution));
	if(maxDisplayTime<=min)
		maxDisplayTime = min+step;
	logSTmp[0].size = (int) ceil((ceil(maxDisplayTime/step)*step-min)/step)+1;
	for(n=0; n<nClade; n++) {
		logSTmp[n].size = logSTmp[0].size;
		logSTmp[n].item = (TypeDistributionItem*) malloc(logSTmp[n].size*sizeof(TypeDistributionItem));
		for(j=0; j<logSTmp[n].size; j++) {
			logSTmp[n].item[j].val = min + ((double)j)*step;
			logSTmp[n].item[j].dens = NEG_INFTY;
		}
	}
	for(s=0; s<iter; s++) {
		int j;
		pext =  getExtendedModelParam(&param);
		for(i=0; i<nClade; i++)
			for(j=0; j<logSTmp[i].size; j++) {
				int k;
				double tmp = 0.;
				for(k=0; clade[i][k]!=END_LIST_INT && logSTmp[i].item[j].val>=tree[0]->time[clade[i][k]]; k++)
					tmp += getLogProbExtinctCond(logSTmp[i].item[j].val, tree[0]->time[clade[i][k]], tree[0]->maxTime, &pext);
				if(clade[i][k] != END_LIST_INT)
					tmp = NEG_INFTY;
				if(tmp != NEG_INFTY)
					logSTmp[i].item[j].dens = logSumLog(logSTmp[i].item[j].dens, tmp);
			}
		saveParam[s] = param;
		for(f=0; f<fp->size; f++)
			save[f][s] = fp->fossilList[f].time;
		for(n=0; n<nExt; n++)
			saveExt[n][s] = tree[0]->time[ext[n]];
		for(j=0; j<gap; j++) {
			prob = update(tree, nTree, fp, fi, fol, branch, prob, al, prop, &param, windSize, probSpe, probExt);
		}

	}
	d = (TypeDistribution*) malloc(nClade*sizeof(TypeDistribution));
	for(n=0; n<nClade; n++) {
		d[n].size = logSTmp[n].size;
		d[n].item = (TypeDistributionItem*) malloc(logSTmp[n].size*sizeof(TypeDistributionItem));
		for(j=0; j<logSTmp[n].size; j++) {
			d[n].item[j].val = logSTmp[n].item[j].val;
			if(logSTmp[n].item[j].dens > NEG_INFTY)
				d[n].item[j].dens = exp(logSTmp[n].item[j].dens-log((double)iter));
			else
				d[n].item[j].dens = 0.;
		}
		free((void*) logSTmp[n].item);
	}
	free((void*) logSTmp);
	for(s=0; s<iter; s++)
		fprintf(fout, "%d\t%lf\n",  s+burn+1, saveParam[s].birth);
	for(s=0; s<iter; s++)
		fprintf(fout, "%d\t%lf\n",  s+burn+1, saveParam[s].death);
	for(s=0; s<iter; s++)
		fprintf(fout, "%d\t%lf\n",  s+burn+1, saveParam[s].fossil);
	free((void*)saveParam);
	for(f=0; f<fp->size; f++)
		for(s=0; s<iter; s++)
			fprintf(fout, "%d\t%lf\n",  s+burn+1, save[f][s]);
	for(f=0; f<fp->size; f++)
		free((void*)save[f]);
	free((void*)save);
	for(n=0; n<nExt; n++)
		for(s=0; s<iter; s++)
			fprintf(fout, "%d\t%lf\n",  s+burn+1, saveExt[n][s]);
	for(n=0; n<nExt; n++)
		free((void*)saveExt[n]);
	free((void*)saveExt);
	int off = 0;
	fprintf(find, "birth\t%d\t%d\n", off*iter+1, (off+1)*iter); off++;
	fprintf(find, "death\t%d\t%d\n", off*iter+1, (off+1)*iter); off++;
	fprintf(find, "fossil\t%d\t%d\n", off*iter+1, (off+1)*iter); off++;
	for(f=0; f<fp->size; f++) {
		fprintf(find, "%d", f+1);
		if(branch[f] != NOSUCH && tree[0]->name[branch[f]] != NULL)
			fprintf(find, "_%s_%d_%d", tree[0]->name[branch[f]], (int) round(fi->fossilIntList[f].fossilInt.inf), (int) round(fi->fossilIntList[f].fossilInt.sup));
		fprintf(find, "\t%d\t%d\n", off*iter+1, (off+1)*iter); off++;
	}
	for(n=0; n<nExt; n++) {
		if(tree[0]->name[ext[n]] != NULL)
			fprintf(find, "%s", tree[0]->name[ext[n]]);
		else
			fprintf(find, "node_%d", ext[n]);
		fprintf(find, "\t%d\t%d\n", off*iter+1, (off+1)*iter); off++;
	}
	free((void*)branch);
	free((void*)fol);
	
	return d;
}

double *MCMCSamplingExtinctionDistQuantMean(FILE *fout, FILE *find, double order, int **clade, TypeTree **tree, TypeFossilIntFeature *fi, double al, int burn, int gap, int iter, double prop, TypeModelParam *windSize, TypeModelParam *init, double probSpe, double probExt) {
	int *fol, *branch, i, j, f, s, n, nTree = 0, nClade = 0, nExt = 0, maxExt, *ext;
	double prob, **save, **saveExt, *quant;
	TypeFossilFeature *fp;
	TypeModelParam param, *saveParam;
	TypeExtendedModelParam pext, *savePext;
	
	param.birth = UNIF_RAND*init->birth;
	param.death = UNIF_RAND*init->death;
	param.fossil = UNIF_RAND*init->fossil;
	param.sampling = 1.;
	fp = sampleFossil(fi, tree[0]->size);
	for(nTree=0; tree[nTree] != NULL; nTree++) {
		for(n=0; n<tree[nTree]->size; n++) {
			if(tree[nTree]->node[n].child == NOSUCH) {
				switch(fi->status[n]) {
					case contempNodeStatus:
						tree[nTree]->time[n] = tree[nTree]->maxTime;
					break;
					case unknownNodeStatus:

					break;
					case extinctNodeStatus:
						tree[nTree]->time[n] = fp->fossilList[fp->fossil[n]].time;
					break;
					default:
	//						error("Node %d has no status\n", n);
	;
				}
			} else
				tree[nTree]->time[n] = NO_TIME;
		}
	}
	savePext = (TypeExtendedModelParam*) malloc(iter*sizeof(TypeExtendedModelParam));
	ext = (int*) malloc(tree[0]->size*sizeof(int));
	maxExt = 0;
	for(n=0; n<tree[0]->size; n++)
		if(tree[0]->node[n].child == NOSUCH && fi->status[n] == extinctNodeStatus) {
			ext[nExt++] = n;
			if(n>maxExt)
				maxExt = n;
		}
	saveExt = (double**) malloc((maxExt+1)*sizeof(double*));
	for(n=0; n<=maxExt; n++)
		saveExt[n] = (double*) malloc(iter*sizeof(double));
	fol = (int*) malloc(fp->size*sizeof(int));
	fillFolNode(fp, tree[0]->size, fol);
	branch = (int*) malloc(fp->size*sizeof(int));
	fillBranchNode(fp, tree[0]->size, branch);
	if(fout != NULL && find != NULL) {
		saveParam = (TypeModelParam*) malloc(iter*sizeof(TypeModelParam));
		save = (double**) malloc(fp->size*sizeof(double*));
		for(f=0; f<fp->size; f++)
			save[f] = (double*) malloc(iter*sizeof(double));
	}
	prob = getLogDensitySum(tree, nTree, fp, &param);
	for(i=0; i<burn; i++) {
		prob = update(tree, nTree, fp, fi, fol, branch, prob, al, prop, &param, windSize, probSpe, probExt);
	}
	for(nClade=0; clade[nClade]!=NULL; nClade++)
		;
	quant = (double*) malloc(nClade*sizeof(double));
	for(s=0; s<iter; s++) {
		pext =  getExtendedModelParam(&param);
		savePext[s] = pext;
		if(fout != NULL && find != NULL) {
			saveParam[s] = param;
			for(f=0; f<fp->size; f++)
				save[f][s] = fp->fossilList[f].time;
		}
		for(n=0; n<nExt; n++) 
			saveExt[ext[n]][s] = tree[0]->time[ext[n]];
		for(j=0; j<gap; j++) {
			prob = update(tree, nTree, fp, fi, fol, branch, prob, al, prop, &param, windSize, probSpe, probExt);
		}
	}
	for(n=0; n<nClade; n++)
		quant[n] = getQuantileCladeSum(clade[n], order, 0.01, tree[0]->maxTime, savePext, saveExt, iter);
	free((void*)savePext);
	if(fout != NULL && find != NULL) {
		for(s=0; s<iter; s++)
			fprintf(fout, "%d\t%lf\n",  s+burn+1, saveParam[s].birth);
		for(s=0; s<iter; s++)
			fprintf(fout, "%d\t%lf\n",  s+burn+1, saveParam[s].death);
		for(s=0; s<iter; s++)
			fprintf(fout, "%d\t%lf\n",  s+burn+1, saveParam[s].fossil);
		free((void*)saveParam);
		for(f=0; f<fp->size; f++)
			for(s=0; s<iter; s++)
				fprintf(fout, "%d\t%lf\n",  s+burn+1, save[f][s]);
		for(f=0; f<fp->size; f++)
			free((void*)save[f]);
		free((void*)save);
		for(n=0; n<nExt; n++)
			for(s=0; s<iter; s++)
				fprintf(fout, "%d\t%lf\n",  s+burn+1, saveExt[ext[n]][s]);
		int off = 0;
		fprintf(find, "birth\t%d\t%d\n", off*iter+1, (off+1)*iter); off++;
		fprintf(find, "death\t%d\t%d\n", off*iter+1, (off+1)*iter); off++;
		fprintf(find, "fossil\t%d\t%d\n", off*iter+1, (off+1)*iter); off++;
		for(f=0; f<fp->size; f++) {
			fprintf(find, "%d", f+1);
			if(branch[f] != NOSUCH && tree[0]->name[branch[f]] != NULL)
				fprintf(find, "_%s_%d_%d", tree[0]->name[branch[f]], (int) round(fi->fossilIntList[f].fossilInt.inf), (int) round(fi->fossilIntList[f].fossilInt.sup));
			fprintf(find, "\t%d\t%d\n", off*iter+1, (off+1)*iter); off++;
		}
		for(n=0; n<nExt; n++) {
			if(tree[0]->name[ext[n]] != NULL)
				fprintf(find, "%s", tree[0]->name[ext[n]]);
			else
				fprintf(find, "node_%d", ext[n]);
			fprintf(find, "\t%d\t%d\n", off*iter+1, (off+1)*iter); off++;
		}
	}
	for(n=0; n<=maxExt; n++)
		free((void*)saveExt[n]);
	free((void*)saveExt);
	free((void*)branch);
	free((void*)fol);
	return quant;
}

double getLogProbExtinctCondCladeSum(double val, int *clade, double maxTime, TypeExtendedModelParam *param, double **time, int size) {
	int i;
	double sumLog = NEG_INFTY;
	for(i=0; i<size; i++) {
		int j;
		double logProb = 0.;
		for(j=0; clade[j] != END_LIST_INT; j++)
			logProb += getLogProbExtinctCond(val, time[clade[j]][i], maxTime, &(param[i]));
		sumLog = logSumLog(sumLog, logProb);
	}
	return sumLog-log((double)size);
}

double getQuantileCladeSum(int *clade, double q, double tol, double maxTime, TypeExtendedModelParam *param, double **time, int size) {
	double a, b;
	int i, j;
	a = time[clade[0]][0];
	for(i=0; i<size; i++)
		for(j=0; clade[j] != END_LIST_INT; j++)
			if(time[clade[j]][i]<a)
				a = time[clade[j]][i];
	b = maxTime;
	while(b-a>tol) {
		double m = (a+b)/2.;
		if(exp(getLogProbExtinctCondCladeSum(m, clade, maxTime, param, time, size))>q)
			b = m;
		else
			a = m;
	}
	return (a+b)/2.;
}

double MCMCSamplingExtinctionComp(FILE *fout, FILE *find, int *cladeA, int *cladeB, TypeTree **tree, TypeFossilIntFeature *fi, double al, int burn, int gap, int iter, double prop, TypeModelParam *windSize, TypeModelParam *init, double probSpe, double probExt) {
	int *fol, *branch, i, j, f, s, n, nTree = 0, nExt = 0, maxExt, *ext;
	double prob, **save, **saveText, sumLog;
	TypeFossilFeature *fp;
	TypeModelParam param, *saveParam;
	TypeExtendedModelParam pext, *savePext;
	
	param.birth = UNIF_RAND*init->birth;
	param.death = UNIF_RAND*init->death;
	param.fossil = UNIF_RAND*init->fossil;
	param.sampling = 1.;
	fp = sampleFossil(fi, tree[0]->size);
	for(nTree=0; tree[nTree] != NULL; nTree++) {
		for(n=0; n<tree[nTree]->size; n++) {
			if(tree[nTree]->node[n].child == NOSUCH) {
				switch(fi->status[n]) {
					case contempNodeStatus:
						tree[nTree]->time[n] = tree[nTree]->maxTime;
					break;
					case unknownNodeStatus:

					break;
					case extinctNodeStatus:
						tree[nTree]->time[n] = fp->fossilList[fp->fossil[n]].time;
					break;
					default:
						;
				}
			} else
				tree[nTree]->time[n] = NO_TIME;
		}
	}
	savePext = (TypeExtendedModelParam*) malloc(iter*sizeof(TypeExtendedModelParam));
	ext = (int*) malloc(tree[0]->size*sizeof(int));
	maxExt = 0;
	for(n=0; n<tree[0]->size; n++)
		if(tree[0]->node[n].child == NOSUCH && fi->status[n] == extinctNodeStatus) {
			ext[nExt++] = n;
			if(n>maxExt)
				maxExt = n;
		}
	saveText = (double**) malloc(iter*sizeof(double*));
	for(s=0; s<iter; s++)
		saveText[s] = (double*) malloc((maxExt+1)*sizeof(double));
	fol = (int*) malloc(fp->size*sizeof(int));
	fillFolNode(fp, tree[0]->size, fol);
	branch = (int*) malloc(fp->size*sizeof(int));
	fillBranchNode(fp, tree[0]->size, branch);
	if(fout != NULL && find != NULL) {
		saveParam = (TypeModelParam*) malloc(iter*sizeof(TypeModelParam));
		save = (double**) malloc(fp->size*sizeof(double*));
		for(f=0; f<fp->size; f++)
			save[f] = (double*) malloc(iter*sizeof(double));
	}
	prob = getLogDensitySum(tree, nTree, fp, &param);
	for(i=0; i<burn; i++) {
		prob = update(tree, nTree, fp, fi, fol, branch, prob, al, prop, &param, windSize, probSpe, probExt);
	}
	sumLog = NEG_INFTY;
	for(s=0; s<iter; s++) {
		pext =  getExtendedModelParam(&param);
		savePext[s] = pext;
		if(fout != NULL && find != NULL) {
			saveParam[s] = param;
			for(f=0; f<fp->size; f++)
				save[f][s] = fp->fossilList[f].time;
		}
		for(n=0; n<nExt; n++) 
			saveText[s][ext[n]] = tree[0]->time[ext[n]];
		sumLog = logSumLog(sumLog, getLogProbComp(cladeA, cladeB, tree[0]->maxTime, &(pext), tree[0]->time));
		for(j=0; j<gap; j++) {
			prob = update(tree, nTree, fp, fi, fol, branch, prob, al, prop, &param, windSize, probSpe, probExt);
		}
	}
	free((void*)savePext);
	if(fout != NULL && find != NULL) {
		for(s=0; s<iter; s++)
			fprintf(fout, "%d\t%lf\n",  s+burn+1, saveParam[s].birth);
		for(s=0; s<iter; s++)
			fprintf(fout, "%d\t%lf\n",  s+burn+1, saveParam[s].death);
		for(s=0; s<iter; s++)
			fprintf(fout, "%d\t%lf\n",  s+burn+1, saveParam[s].fossil);
		free((void*)saveParam);
		for(f=0; f<fp->size; f++)
			for(s=0; s<iter; s++)
				fprintf(fout, "%d\t%lf\n",  s+burn+1, save[f][s]);
		for(f=0; f<fp->size; f++)
			free((void*)save[f]);
		free((void*)save);
		for(n=0; n<nExt; n++)
			for(s=0; s<iter; s++)
				fprintf(fout, "%d\t%lf\n",  s+burn+1, saveText[s][ext[n]]);
		int off = 0;
		fprintf(find, "birth\t%d\t%d\n", off*iter+1, (off+1)*iter); off++;
		fprintf(find, "death\t%d\t%d\n", off*iter+1, (off+1)*iter); off++;
		fprintf(find, "fossil\t%d\t%d\n", off*iter+1, (off+1)*iter); off++;
		for(f=0; f<fp->size; f++) {
			fprintf(find, "%d", f+1);
			if(branch[f] != NOSUCH && tree[0]->name[branch[f]] != NULL)
				fprintf(find, "_%s_%d_%d", tree[0]->name[branch[f]], (int) round(fi->fossilIntList[f].fossilInt.inf), (int) round(fi->fossilIntList[f].fossilInt.sup));
			fprintf(find, "\t%d\t%d\n", off*iter+1, (off+1)*iter); off++;
		}
		for(n=0; n<nExt; n++) {
			if(tree[0]->name[ext[n]] != NULL)
				fprintf(find, "%s", tree[0]->name[ext[n]]);
			else
				fprintf(find, "node_%d", ext[n]);
			fprintf(find, "\t%d\t%d\n", off*iter+1, (off+1)*iter); off++;
		}
	}
	free((void*)ext);
	freeFossilFeature(fp);
	for(s=0; s<iter; s++)
		free((void*)saveText[s]);
	free((void*)saveText);
	free((void*)branch);
	free((void*)fol);
	return sumLog-log((double)iter);
}

double getLogProbComp(int *cladeA, int *cladeB, double maxTime, TypeExtendedModelParam *param, double *time) {
	double a, b, step = 0.1, result;
	int j;
	TypeDistribution d;

	a = time[cladeA[0]];
	for(j=1; cladeA[j] != END_LIST_INT; j++)
		if(time[cladeA[j]]>a)
			a = time[cladeA[j]];
	a += 0.00000001;
	b = time[cladeB[0]];
	for(j=1; cladeB[j] != END_LIST_INT; j++)
		if(time[cladeB[j]]>b)
			b = time[cladeB[j]];
	b += 0.00000001;
	d.size = (int) ceil((maxTime-a)/step);
	d.item = (TypeDistributionItem*) malloc(d.size*sizeof(TypeDistributionItem));
	for(j=0; j<d.size; j++) {
			d.item[j].val = a + ((double)j)*step;
			if(d.item[j].val>b)
				d.item[j].dens = exp(getLogDensClade(d.item[j].val, cladeA, time, maxTime, param)+getLogProbClade(d.item[j].val, cladeB, time, maxTime, param));
			else
				d.item[j].dens = 0.;
	}
	result = sumSimpsonDistribution(d);
	free((void*)d.item);
	return log(result);
}
