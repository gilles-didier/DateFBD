

#library(ade4)
#library(ape)
#dyn.load("treeR.so")

#testTree <- function(tree, part) {
#phy <- read.tree(tree)
#.Call("drawPhylo", phy, "bof.tex")
#list <- scan(part, what = " ")
#new <- .Call("prunePhylo", phy, list)
#phy2 <- read.tree(text = new)
#}

FBDdiagnostic <- function(treeName, fossilName, outName = "coda_output.out", indName = "coda_output.ind", inf_origin=NaN, sup_origin=NaN, end_time=0., spec_wind_size=1., exti_wind_size=0.5, foss_wind_size=0.5, spec_init=1., exti_init=0.5, foss_init=0.5, iter=2000, prop = 0.5, al = 0.75, burn = 10000, thin = 300, prop_spe = 0.33, prop_ext = 0.33) {
	res <-.Call("getFBDDiagnostic", treeName, fossilName, outName, indName, inf_origin, sup_origin, end_time, spec_init, exti_init, foss_init, spec_wind_size, exti_wind_size, foss_wind_size, prop, iter, al,  burn, thin, prop_spe, prop_ext)
	res
}

FBDspeciation_distribution <- function(cladeName, treeName, fossilName, outName = "coda_output.out", indName = "coda_output.ind", inf_origin=NaN, sup_origin=NaN, end_time=0., spec_wind_size=1., exti_wind_size=0.5, foss_wind_size=0.5, spec_init=1., exti_init=0.5, foss_init=0.5, iter=2000, prop = 0.5, step=0.1, al = 0.75, burn = 10000, thin = 300, prop_spe = 0.33, prop_ext = 0.33, outDens = TRUE) {
	res <-.Call("getFBDSpeciationDistribution", cladeName, treeName, fossilName, outName, indName, inf_origin, sup_origin, end_time, spec_init, exti_init, foss_init, spec_wind_size, exti_wind_size, foss_wind_size, prop, iter, step, al,  burn, thin, prop_spe, prop_ext, outDens)
	res
}

FBDextinction_distribution <- function(tableTaxaName, tableCladeName, treeName, fossilName, outName = "coda_output.out", indName = "coda_output.ind", inf_origin=NaN, sup_origin=NaN, end_time=0., spec_wind_size=1., exti_wind_size=0.5, foss_wind_size=0.5, spec_init=1., exti_init=0.5, foss_init=0.5, iter=2000, prop = 0.5, step=0.1, al = 0.75, burn = 10000, thin = 300, prop_spe = 0.33, prop_ext = 0.33, maxDisplayTime = 0., outDens = TRUE) {
	res <-.Call("getFBDExtinctionDistribution", tableTaxaName, tableCladeName, treeName, fossilName, outName, indName, inf_origin, sup_origin, end_time, spec_init, exti_init, foss_init, spec_wind_size, exti_wind_size, foss_wind_size, prop, iter, step, al,  burn, thin, prop_spe, prop_ext, maxDisplayTime, outDens)
	res
}

FBDextinction_upperBound <- function(tableTaxaName, tableCladeName, treeName, fossilName, outName = "coda_output.out", indName = "coda_output.ind", order = 0.95, inf_origin=NaN, sup_origin=NaN, end_time=0., spec_wind_size=1., exti_wind_size=0.5, foss_wind_size=0.5, spec_init=1., exti_init=0.5, foss_init=0.5, iter=2000, prop = 0.5, al = 0.75, burn = 10000, thin = 300, prop_spe = 0.33, prop_ext = 0.33) {
	res <-.Call("getFBDExtinctionUpperBounds", order, tableTaxaName, tableCladeName, treeName, fossilName, outName, indName, inf_origin, sup_origin, end_time, spec_init, exti_init, foss_init, spec_wind_size, exti_wind_size, foss_wind_size, prop, iter, al,  burn, thin, prop_spe, prop_ext)
	res
}

FBDextinction_comparison <- function(tableTaxaNameA, tableTaxaNameB, treeName, fossilName, outName = "coda_output.out", indName = "coda_output.ind", order = 0.95, inf_origin=NaN, sup_origin=NaN, end_time=0., spec_wind_size=1., exti_wind_size=0.5, foss_wind_size=0.5, spec_init=1., exti_init=0.5, foss_init=0.5, iter=2000, prop = 0.5, al = 0.75, burn = 10000, thin = 300, prop_spe = 0.33, prop_ext = 0.33) {
	res <-.Call("getFBDExtinctionComparison", tableTaxaNameA, tableTaxaNameB, treeName, fossilName, outName, indName, inf_origin, sup_origin, end_time, spec_init, exti_init, foss_init, spec_wind_size, exti_wind_size, foss_wind_size, prop, iter, al,  burn, thin, prop_spe, prop_ext)
	res
}
